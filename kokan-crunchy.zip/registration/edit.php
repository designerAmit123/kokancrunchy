<?php
session_start();

include('config/config.php');

$ids = $_GET['id'];

$show_query = "SELECT * FROM user WHERE id = {$ids}";

$show_data = mysqli_query($con, $show_query);

$arr_data = mysqli_fetch_array($show_data);


if(isset($_POST['submit'])){
	$update_id = $_GET['id'];

	$name = mysqli_real_escape_string($con, $_POST['name']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$mobile = mysqli_real_escape_string($con, $_POST['mobile']);
	
	
	
	
	$update_query = " UPDATE user SET id=$ids, name = '$name', email = '$email', mobile= '$mobile'  WHERE id = $update_id ";

	$query = mysqli_query($con, $update_query);

	if($query){
		?>
		<script>
			location.replace("../index.php");
			alert("data updated successfully");
		</script>
		<?php
	}else{
		?>
		<script>
			alert("data not updated successfully");
		</script>
		<?php
	}
}

?>
<!DOCTYPE html>
<html lang="zxx">
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<head>
	<title>Kokan Crunchy - Top quality Dry-Fruits Products| Edit User Information</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
    <link rel="stylesheet" href="https://cdn.snipcart.com/themes/v3.0.23/default/snipcart.css" />
    
    
	<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="../css/font-awesome.css" rel="stylesheet">
	<!--pop-up-box-->
	<link href="../css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!--//pop-up-box-->
	<!-- price range -->
	<link rel="stylesheet" type="text/css" href="../css/jquery-ui1.css">
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    	
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	
</head>

<body>
	
	<?php include('header.php'); ?>
	<!-- banner-2 -->
	<div class="page-head_agile_info_w3l">

	</div>
	<!-- //banner-2 -->
	<!-- page -->
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="../index.php"><i class="fa fa-home"></i></a>
						<i>|</i>
					</li>
					<li>
						<a href="../my-account.php">Account</a>
						<i>|</i>
					</li>
					<li>Edit Information </li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //page -->
	<!-- Terms of use-section -->
	<section class="terms-of-use">
		<!-- terms -->
		<div class="terms">
			<div class="container">
				<div class="account_sec1">
					<h3 class="tittle-w3c">My Account Information</h3>
					<h5>Your Personal Details</h5>
				</div>
				<div class="edit_user">
					<form action="" method="post">
						<div class="styled-input agile-styled-input-top">
							<input type="text" name="name" value="<?php echo($arr_data['name']);?>" name="name" required="">
						</div>
						<div class="styled-input agile-styled-input-top">
							<input type="text" name="email" value="<?php echo($arr_data['email']);?>" name="email" required="">
						</div>
						<div class="styled-input agile-styled-input-top">
							<input type="text" name="mobile" value="<?php echo($arr_data['mobile']);?>" name="mobile" required="">
						</div>
						<input type="submit" name="submit" value="Submit">
					</form>
				</div>
				
			</div>
		</div>
		<!-- /terms -->
	</section>
	<!-- //Terms of use-section -->

	<?php include('footer.php'); ?>

</body>

</html>