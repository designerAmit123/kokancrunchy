<?php 
    $server = "localhost";
    $user = "amitkdu20_uideveloper";
    $password = "designer@Amit123";
    $dbname = "amitkdu20_uideveloper";
    
    $con = mysqli_connect($server, $user, $password, $dbname);
    
    if($con){
        ?>
        
        <?php
    }else{
        ?>
        <script>
            alert("Database not connected please connect");
        </script>
        <?php
    }
?>